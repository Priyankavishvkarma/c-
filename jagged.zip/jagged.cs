﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication10
{
    class Program
    {
        static void Main(string[] args)
        {
            int[][] C = new int[4][];
            C[0]=new int[]{1,2,3,4};
            C[1] = new int[] { 1, 2, 3, 4 ,5};
            C[2] = new int[] { 1, 2, 3, 4,5,6 };
            C[3] = new int[] { 1, 2, 3, 4 ,5,6,7};
            for (int i = 0; i < C.Length; i++)
            {
                for (int j = 0;j<C[i].Length;j++)
                {
                    Console.Write(C[i][j]);

                }
                Console.WriteLine();
            }
                Console.Read();
            
        }
    }
}
 
