﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication15
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("enter any number:");
            int n = Convert.ToInt32(Console.ReadLine());
            int i =1,Old=0,New=0;
            
                do{
                    if(i<=3)
                    {
                        Console.Write(i);
                        New=i;
                        Old=i-1;


                    }
                    else
                    {
                        int temp=Old*New;
                        if(temp>n)
                        {
                            break;

                        }
                        Console.Write(temp);
                        Old=New;
                        New=temp;



                    }
                    i++;

            }while(i<=n);

            Console.Read();

        }
    }
}
