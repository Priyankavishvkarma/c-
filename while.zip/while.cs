﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication8
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("enter any number");
            int n = Convert.ToInt32(Console.ReadLine());
            int i =1, k = 1, Old = 0, New = 0 ,temp=0;
            do
            {
                int j=1;

                do
                {
                    if(k<=3)
                    {
                    Console.Write(k);
                    New=k;
                    Old=k-1;

                }
                else
                {
                    temp=Old*New;
                    if(temp>n)
                    {
                        break;

                    }
                    Console.Write(temp);
                    Old=New;
                    New=temp;

                }
                k++;
                j++;

            
            }
            while(j<=i);

            if(temp>n)
            {
                break;

            }
            Console.WriteLine();
            i++;


            
        
        }while(i<=n);
        Console.Read();


    }
}
}